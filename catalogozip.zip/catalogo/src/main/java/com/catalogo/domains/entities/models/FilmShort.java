package com.catalogo.domains.entities.models;

public interface FilmShort {

}
