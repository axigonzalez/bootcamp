package com.catalogo.domains.entities.models;

public class FilmDTO {

}
